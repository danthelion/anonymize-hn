# Anonymize HN

Chrome extension that anonymizes Hacker News users.